package module1;

public class Method {
  int val=50;
	int op(int r) {
	r=r+5;
	return(r);
	}
  public static void main(String args[]) {
   Method a = new Method();
   System.out.println("Before operation "+a.val);
   a.op(35);
   System.out.println("After operation "+a.val);
 }
}
