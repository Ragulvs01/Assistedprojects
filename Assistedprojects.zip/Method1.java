package module1;

public class Method1 {
  public int addnumbers(int a,int b) {
	  int c=a+b;
   	  return c;
   }
  public static void main(String[] args) {
	Method1 b=new Method1();
    int d= b.addnumbers(5,13);
     System.out.println("Addition of two number is :"+d);
  }
}
