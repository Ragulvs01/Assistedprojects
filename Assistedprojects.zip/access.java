class default1
{ 
 void show() 
     { 
         System.out.println("Hello all"); 
     } 
} 
public class access {
	public static void main(String[] args) {
		default1 s = new default1(); 
		s.show();
		System.out.println("Hii how are you");
		default1 r = new default1(); 		  
        r.show(); 
	}
}
