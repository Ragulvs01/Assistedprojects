class specifier
{ 
  private void show() 
   { 
     System.out.println("This is private we cannot access outside the class"); 
   } 
  public void call()
   {
  System.out.println("This is public so we easily access the class outside");
   }
} 
public class access1 {
	public static void main(String[] args) {
		System.out.println("Access specifier private");
		specifier  r = new specifier(); 
		//r.show();
		r.call();
	}
}
