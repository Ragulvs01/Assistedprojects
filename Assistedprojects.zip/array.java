package module1;

public class array {
  public static void main(String[] args) {
  int a[]= {1,2,3,4,5};
  for(int i=0;i<5;i++) {
  System.out.println("Elements of array a: "+a[i]);
  }
	int[][] b = {{1, 2, 3, 4},{5, 6, 7,8}}; 
	System.out.println("\nLength of row 1: " + b[0].length);
	for(int j=0;j<b[0].length;j++) {
		for(int k=0;k<b[0].length;k++) {
			System.out.println("Elements of 2D array b is: "+b[j][k]);
		}
	}
  }
}
