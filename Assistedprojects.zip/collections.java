package module1;
import java.util.*;
public class collections {
  public static void main(String[] args) {
      System.out.println("Array collection");
	  ArrayList<Integer>num=new ArrayList<Integer>();   
	  num.add(100);
      num.add(200);
      num.add(300);
	  System.out.println(num);  
	  System.out.println("\n");
      System.out.println("Linkedlist collection");
      LinkedList<String> name=new LinkedList<String>();  
      name.add("Somu");  
	  name.add("Mozhi");
	  name.add("dharan");
	  Iterator<String> itr=name.iterator();  
	  while(itr.hasNext()){  
	  System.out.println(itr.next());
	  }
	  System.out.println("\n");
	  System.out.println("Vector Collection");
	  Vector<Integer> a = new Vector();
	  a.addElement(5); 
	  a.addElement(21);
	  a.addElement(45);
	  System.out.println(a);
	  System.out.println("\n");
      System.out.println("LinkedHashSet Collection");
      LinkedHashSet<Integer>b=new LinkedHashSet<Integer>();  
      b.add(100);  
      b.add(200);  
      b.add(300);
      b.add(400);	      
      System.out.println(b);
      System.out.println("\n");
      System.out.println("HashSet Collection");
      HashSet<String> c=new HashSet<String>();  
      c.add("101");  
      c.add("202");  
      c.add("303");
      c.add("404");
      System.out.println(c);
 	} 
}
