package module1;
class vehicle {
	vehicle() {
		System.out.println("Object created...");
	}
	void displayCarInfo() {
		System.out.println("Car Details");
	}
}

public class constructor {
	public static void main(String args[]) {
		vehicle innova = new vehicle();
		innova.displayCarInfo();
	}
}
