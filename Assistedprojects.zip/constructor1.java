package module1;
class Op {
	int a,b,sum;
	Op() {
		a=10;
		b=20;
	}
	Op(int x, int y){
		a=x;
		b=y;
	}
	void setValue(int x, int y) {
		a=x;
		b=y;
	}
	void add() {
		sum = a+b;
	}
	void display() {
		System.out.println("sum is "+sum);
	}
}

public class constructor1 {
	public static void main(String args[]) {
		Op op1 = new Op();
		op1.setValue(2,3);
		op1.add();
		op1.display();
		Op op2 = new Op();							
		op2.add();		
		op2.display();
		Op op3 = new Op();
		op3.setValue(100,200);	
		op3.add();		
		op3.display();
		Op op4 = new Op(11,22);					
		op4.add();			
		op4.display();
		
		}

}
