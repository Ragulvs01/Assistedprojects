package module1;

public class innerclass {
  private String a="Hello all"; 
  class Inner{  
  void method(){System.out.println(a+",Welcome to India");}  
   }  
  public static void main(String[] args) {
	innerclass b=new innerclass();
	innerclass.Inner c=b.new Inner();  
    c.method();  
	}
}
