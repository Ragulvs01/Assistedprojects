package module1;
import java.util.*;
public class map {
 public static void main(String[] args) {
	 HashMap<String,Integer> a=new HashMap<String,Integer>();      
     a.put("Ram",5);    
     a.put("Somu",3);    
     a.put("Dharani",1);   
     System.out.println("\nThe Hashmap elements are: ");  
     for(Map.Entry d:a.entrySet()){    
      System.out.println(d.getKey()+" "+d.getValue());    
     }		       
     TreeMap<String,Integer> b=new TreeMap<String,Integer>();    
     b.put("Hii",2);    
     b.put("How are you",4);    
     b.put("How do you feel today",6);       
     System.out.println("\nThe treemap are: ");  
     for(Map.Entry e:b.entrySet()){    
      System.out.println(e.getKey()+" "+e.getValue());    
     }    
     Hashtable<String,Integer> c=new Hashtable<String,Integer>();
     c.put("Oh God",3);  
     c.put("Today is a great day",6);  
     c.put("All the best",8);
     System.out.println("\nThe hashtable are: ");  
     for(Map.Entry f:c.entrySet()){    
      System.out.println(f.getKey()+" "+f.getValue());    
     }            
   }  
}
