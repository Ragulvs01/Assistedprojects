package module1;

public class method2 {
  public void add(int a,int b)
   {
      System.out.println("The sum: "+(a+b));
	}
   public void product(int c) 
    {
	  System.out.println("The product: "+(c*c));
    }
  public static void main(String args[])
    {
	 method2 d=new method2();
	 d.add(36,73);
	 d.product(225);  
   }
}
