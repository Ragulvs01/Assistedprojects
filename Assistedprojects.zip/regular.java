package module1;
import java.util.regex.*;
public class regular {
	public static void main(String[] args) {
	String x = "[A-Z]+";
	String statement = "How are YOu and How oLD arE you";
	Pattern a = Pattern.compile(x);
	Matcher b= a.matcher(statement);	
	while (b.find()) {
	  	System.out.println( statement.substring( b.start(), b.end() ) );
		}
	}
}
