package module1;

public class string {
  public static void main(String[] args) {
	System.out.println("Types of String operations");
	String a=new String("Hello World");
	System.out.println(a.length());
	String b="hii";
	System.out.println(b.isEmpty());		
	String c=new String("hello world");
	System.out.println(c.substring(3));		
	String D="HAVING all";
	System.out.println(D.toLowerCase());
	System.out.println(D.toUpperCase());
	String e="House";
	String f="Hosuing";
	System.out.println(e.compareTo(f));
	String g="Gokal";
	String h=g.replace('a', 'u');
	System.out.println(h);		
	String i="Hello All";
	String j="hello all";
	System.out.println(i.equals(j));
	System.out.println(i.equalsIgnoreCase(j));
	System.out.println("\n");		
	StringBuffer k=new StringBuffer("Hello all");
	k.append("Hope you are safe");
	System.out.println(k);
	k.insert(0, '1');
	System.out.println(k);		
	StringBuffer l=new StringBuffer("Hiiiiii");
	l.replace(0, 3, "how");
	System.out.println(l);		
	l.delete(0, 3);
	System.out.println(l);		
	System.out.println("\n");
	StringBuilder m=new StringBuilder("hello all");
	m.append("Welcome to India");
	System.out.println(m);
	System.out.println(m.delete(0, 4));
	System.out.println(m.insert(5, "Welcome"));
	System.out.println(m.reverse());		
	System.out.println("\n");
	String n = "Vanakam"; 
	StringBuffer o = new StringBuffer(n); 
    o.reverse(); 
    System.out.println(o); 		
    StringBuilder p = new StringBuilder(n); 
    p.append(" Thalaiva"); 
    System.out.println(p);             		
		}
}
