
public class typecasting {

	public static void main(String[] args) {
	    
		char c= 'A';
		System.out.println("The output is " +c);
		int i=c;
		System.out.println("The output is " +i);
		float f=i;
		System.out.println("The output is " +f);
		double d=f;
		System.out.println("The output is " +d);
		
		float f1= (float)d;
		System.out.println("The output is " +f1);
		int i1=(int)f1;
		System.out.println("The output is " +i1);
		char c1= (char)i1;
		System.out.println("The output is " +c1);
		
		//int v=99;
		//char s=(char)v;
		//System.out.println("The output is" +s);
	}

}
